# Twitter-Sentiment-Analysis-Supervised-Learning
A Twitter Sentiment Analysis model developed using python and NLTK (NLP Library)
